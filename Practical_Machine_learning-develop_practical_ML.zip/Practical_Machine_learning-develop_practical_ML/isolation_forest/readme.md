# Anomaly detection using iforest

**Anomaly detection** is an interesting topic that is gaining interest in different industries. Anomaly detection algorithms in health care can point to health issues of patients and in the financial world, they can flag frauds. **Isolation forest** first was introduced in 2008 and gained a lot of interest since then.

Please watch my [Youtube video](https://www.youtube.com/watch?v=qNDcPUeCEPI) regarding isolation forest [here.](https://www.youtube.com/watch?v=qNDcPUeCEPI)
